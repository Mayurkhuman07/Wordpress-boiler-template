ace.define("ace/snippets/ocaml",["require","exports","module"],function(e,t,n){"use strict";t.snippetText="",t.scope="ocaml"});
                (function() {
                    ace.require(["ace/snippets/ocaml"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            