ace.define("ace/snippets/sjs",["require","exports","module"],function(e,t,n){"use strict";t.snippetText="",t.scope="sjs"});
                (function() {
                    ace.require(["ace/snippets/sjs"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            