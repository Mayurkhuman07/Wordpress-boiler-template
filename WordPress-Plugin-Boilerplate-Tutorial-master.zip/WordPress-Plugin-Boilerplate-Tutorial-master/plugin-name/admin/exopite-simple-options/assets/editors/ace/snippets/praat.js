ace.define("ace/snippets/praat",["require","exports","module"],function(e,t,n){"use strict";t.snippetText="",t.scope="praat"});
                (function() {
                    ace.require(["ace/snippets/praat"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            